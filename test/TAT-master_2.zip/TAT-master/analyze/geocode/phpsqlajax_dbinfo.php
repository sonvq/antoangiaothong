<?php
$username="root";
$password="";
$database="databaselocation";
?>