# TAT

20/10/16 (TAT)
- gif visualize
- interactive visualize/ heatmap
- heideltime, NER, gazetteer
- BRAT: word segmentation, sentence spliting, tag set, import to mysql
- Retrieve: 24h, tintuc, giaothong, (static) search engine
- Display: content + image
- Host: php, mysql, java, python

30/11/16
- Setup java + php (8000)
- Setup webanno
- Load thumbnail image instead of original image
- Get time + location for summarizing + statistics
