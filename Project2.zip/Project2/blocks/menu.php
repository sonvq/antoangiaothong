<!--Begin: menu -->
<div id="menu">
	<!--Begin: menu-bar -->
  <div id="menu-bar">
     <ul>
  	   <li><a href="index.php">Trang chủ</a></li>
       <div id="border"></div>                    
       <li><a href="#">Khu vực</a>
         	<ul>
             	<li><a href="#">Hà Nội</a></li>
                <li><a href="#">Tp. Hồ Chí Minh</a></li>
            </ul>
       </li>
       <div id="border"></div> 
       <li><a href="#">Năm</a>
         	<ul>
          		<li><a href="#">2016</a></li>
               	<li><a href="#">2015</a></li>
               	<li><a href="#">2014</a></li>
               	<li><a href="#">2013</a></li>
               	<li><a href="#">2012</a></li>
    	    </ul>
        </li>
        <div id="border"></div> 
        <li><a href="#">Thống kê</a>
           	<ul>
               	<li><a href="#">Bản đồ</a></li>
                <li><a href="#">Biểu đồ</a></li>
            </ul>
        </li>
        <div id="border"></div> 
        <li><a href="#">Giới thiệu</a></li>
      </ul>
     </div>
      <!--End: menu-bar -->
  	 <div id="search">
     <form action="timkiem.php" method="get">   
    <input type="text" name="q" placeholder="Nhập nội dung tìm kiếm" maxlength="120" width="">
    <input type="submit" value="Tìm Kiếm" name="submit">
</form>
     </div>
</div>
<!--End: menu -->